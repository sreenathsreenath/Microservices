package com.example.order;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class OrderService {

	@Autowired
	private OrderRepository repo;
	
	public List<Order> showOrder(){
		return repo.findAll();
	}
	
	public Order search(int ordId) {
		return repo.findById(ordId).get();
	}
}
